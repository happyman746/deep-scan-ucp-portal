document.addEventListener('DOMContentLoaded', () => {
    const scanBtn = document.getElementById('scanBtn');
    const statusDiv = document.getElementById('status');
    const baseUrl = "https://horizon.ucp.edu.pk";

    loadStoredData();

    scanBtn.addEventListener('click', async () => {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        
        if (!tab || !tab.url.includes('horizon.ucp.edu.pk')) {
            statusDiv.textContent = "Error: Open Dashboard first!";
            return;
        }

        statusDiv.textContent = "Locating 8 Subjects...";
        scanBtn.disabled = true;

        chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: () => {
                const subjectLinks = Array.from(document.querySelectorAll('a'))
                    .filter(a => a.innerText.toLowerCase().includes('active class'))
                    .map(a => {
                        const card = a.closest('.card') || a.closest('div[class*="card"]');
                        let subjectName = card?.querySelector('.card-header, thead, th, h3, h4, b, strong')?.innerText.trim() || "Subject";
                        subjectName = subjectName.split('\n')[0].trim();
                        return { name: subjectName, url: a.href };
                    });
                return subjectLinks.filter((v, i, a) => a.findIndex(t => (t.url === v.url)) === i);
            }
        }, async (results) => {
            const courses = results[0].result;
            if (!courses || courses.length === 0) {
                statusDiv.textContent = "No subjects found!";
                scanBtn.disabled = false;
                return;
            }

            // Purana data load kar rahe hain taake history bani rahe
            chrome.storage.local.get(['scanData'], async (res) => {
                let allData = res.scanData || { materials: [], assignments: [], announcements: [] };

                for (let course of courses) {
                    statusDiv.textContent = `Scanning: ${course.name}...`;
                    try {
                        const response = await fetch(course.url);
                        const html = await response.text();
                        const doc = new DOMParser().parseFromString(html, 'text/html');
                        const subLinks = Array.from(doc.querySelectorAll('a'));
                        
                        const targets = [
                            { type: 'materials', keywords: ['course material'] },
                            { type: 'assignments', keywords: ['submission'] },
                            { type: 'announcements', keywords: ['announcement/news', 'announcements'] }
                        ];

                        for (let target of targets) {
                            const found = subLinks.find(l => target.keywords.some(k => l.innerText.toLowerCase().includes(k)));
                            if (found) {
                                let finalUrl = found.href.startsWith('http') ? found.href : baseUrl + found.getAttribute('href');
                                const resTab = await fetch(finalUrl);
                                const tabDoc = new DOMParser().parseFromString(await resTab.text(), 'text/html');
                                const rows = tabDoc.querySelectorAll('table tbody tr');
                                
                                rows.forEach(row => {
                                    const cols = row.querySelectorAll('td');
                                    if (cols.length >= 2 && !row.innerText.includes("No record")) {
                                        let title = cols[1]?.innerText.trim();
                                        
                                        // Addition: Status Check (Submitted or Not)
                                        let status = ""; 
                                        if (target.type === 'assignments') {
                                            status = row.innerText.toLowerCase().includes('submitted') ? "✅ Submitted" : "❌ Missed/Pending";
                                        }

                                        let entry = {
                                            title: title,
                                            course: course.name,
                                            date: cols[cols.length - 1]?.innerText.trim(),
                                            link: finalUrl,
                                            status: status,
                                            scanDate: Date.now() // 7 din ke filter ke liye timestamp
                                        };

                                        // Duplicate check: Title aur Course match karein
                                        const exists = allData[target.type].findIndex(item => item.title === title && item.course === course.name);
                                        if (exists > -1) allData[target.type][exists] = entry; 
                                        else allData[target.type].push(entry);
                                    }
                                });
                            }
                        }
                    } catch (e) { console.error("Failed: " + course.name); }
                }

                chrome.storage.local.set({ scanData: allData });
                renderData(allData);
                statusDiv.textContent = "Deep Scan Complete!";
                scanBtn.disabled = false;
            });
        });
    });

    function renderData(data) {
        // Addition: 7 Din ka Filter Logic
        const sevenDaysInMs = 7 * 24 * 60 * 60 * 1000;
        const now = Date.now();

        const renderSection = (id, list, css) => {
            // Sirf wo data jo 7 din purana nahi hai
            const filteredList = list.filter(item => (now - item.scanDate) < sevenDaysInMs);

            document.getElementById(id).innerHTML = filteredList.reverse().map(i => `
                <div class="item">
                    <span class="tag ${css}">${i.course}</span>
                    <a href="${i.link}" target="_blank" title="${i.title}">${i.title}</a>
                    <span class="meta">⏰ ${i.date}</span>
                    ${i.status ? `<span class="meta" style="font-weight:bold; color:${i.status.includes('✅')?'green':'red'}">${i.status}</span>` : ''}
                </div>`).join('') || "<p class='empty-msg'>Nothing found in last 7 days.</p>";
        };
        renderSection('materialsList', data.materials, 'tag-mat');
        renderSection('assignmentsList', data.assignments, 'tag-assign');
        renderSection('announcementsList', data.announcements, 'tag-news');
    }

    function loadStoredData() {
        chrome.storage.local.get(['scanData'], (res) => { if(res.scanData) renderData(res.scanData); });
    }
});