// Background service worker for UCP Deep Scan
chrome.runtime.onInstalled.addListener(() => {
  console.log("UCP Deep Scan Extension Installed");
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "startDeepScan") {
        // Filhal sirf success bhejo taake button error na de
        sendResponse({ success: true, data: { materials: [], assignments: [], announcements: [] } });
    }
    return true;
});