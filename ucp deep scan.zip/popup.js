document.addEventListener('DOMContentLoaded', () => {
    const scanBtn = document.getElementById('scanBtn');
    const statusDiv = document.getElementById('status');
    const baseUrl = "https://horizon.ucp.edu.pk";

    loadStoredData();

    scanBtn.addEventListener('click', async () => {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        
        if (!tab.url.includes('horizon.ucp.edu.pk')) {
            statusDiv.textContent = "Error: Open Dashboard first!";
            return;
        }

        statusDiv.textContent = "Locating subjects...";
        scanBtn.disabled = true;

        chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: () => {
                const subjectLinks = Array.from(document.querySelectorAll('a'))
                    .filter(a => a.href.includes('/student/course/') || a.innerText.toLowerCase().includes('active class'))
                    .map(a => {
                        // Card dhoondna
                        const card = a.closest('.card') || a.parentElement.closest('div[class*="card"]');
                        
                        // Subject Name nikalna (Teacher name skip karne ke liye)
                        // UCP Dashboard par aksar h3 ya h4 mein subject hota hai
                        let subjectName = card?.querySelector('h3, h4, .card-title, b')?.innerText.trim() || "Subject";
                        
                        // Clean up: Agar name mein extra spaces ya lines hon
                        subjectName = subjectName.split('\n')[0].trim();

                        let fullUrl = a.href;
                        if (fullUrl.startsWith('chrome-extension://')) {
                            const path = a.getAttribute('href');
                            fullUrl = "https://horizon.ucp.edu.pk" + path;
                        }
                        return { name: subjectName, url: fullUrl };
                    });
                return subjectLinks.filter((v, i, a) => a.findIndex(t => (t.url === v.url)) === i);
            }
        }, async (results) => {
            const courses = results[0].result;
            if (!courses || courses.length === 0) {
                statusDiv.textContent = "No subjects found!";
                scanBtn.disabled = false;
                return;
            }

            let allData = { materials: [], assignments: [], announcements: [] };

            for (let course of courses) {
                statusDiv.textContent = `Scanning: ${course.name}...`;
                
                try {
                    const response = await fetch(course.url);
                    const html = await response.text();
                    const doc = new DOMParser().parseFromString(html, 'text/html');
                    
                    const subLinks = Array.from(doc.querySelectorAll('a'));
                    const targets = [
                        { type: 'materials', keywords: ['material', 'course material'] },
                        { type: 'assignments', keywords: ['submission', 'assignment', 'assessments'] },
                        { type: 'announcements', keywords: ['announcement', 'news'] }
                    ];

                    for (let target of targets) {
                        const found = subLinks.find(l => target.keywords.some(k => l.innerText.toLowerCase().includes(k)));
                        
                        if (found) {
                            let targetPath = found.getAttribute('href');
                            let finalUrl = targetPath.startsWith('http') ? targetPath : baseUrl + targetPath;

                            const res = await fetch(finalUrl);
                            const tabHtml = await res.text();
                            const tabDoc = new DOMParser().parseFromString(tabHtml, 'text/html');
                            
                            const rows = tabDoc.querySelectorAll('table tbody tr');
                            rows.forEach(row => {
                                const cols = row.querySelectorAll('td');
                                if (cols.length >= 3) {
                                    const title = cols[1].innerText.trim();
                                    if (title.includes("No record") || title.includes("No Submission") || title === "Sr No.") return;

                                    const dateStr = cols.length >= 5 ? cols[4].innerText.trim() : "Recent";
                                    
                                    allData[target.type].push({
                                        title: title,
                                        course: course.name, // Ab ye "Linear Algebra" ya "Data Structures" hoga
                                        date: dateStr,
                                        link: finalUrl
                                    });
                                }
                            });
                        }
                    }
                } catch (e) { console.error("Failed: " + course.name); }
            }

            chrome.storage.local.set({ scanData: allData, lastScanDate: new Date().toISOString() });
            renderData(allData);
            statusDiv.textContent = "Deep Scan Complete!";
            scanBtn.disabled = false;
        });
    });

    function renderData(data) {
        const renderSection = (id, list, css) => {
            document.getElementById(id).innerHTML = list.map(i => `
                <div class="item">
                    <span class="tag ${css}">${i.course}</span>
                    <a href="${i.link}" target="_blank" title="${i.title}">${i.title}</a>
                    <span class="meta">${i.date}</span>
                </div>`).join('') || "<p class='empty-msg'>Nothing found recently.</p>";
        };
        renderSection('materialsList', data.materials, 'tag-mat');
        renderSection('assignmentsList', data.assignments, 'tag-assign');
        renderSection('announcementsList', data.announcements, 'tag-news');
    }

    function loadStoredData() {
        chrome.storage.local.get(['scanData'], (res) => { if(res.scanData) renderData(res.scanData); });
    }
});